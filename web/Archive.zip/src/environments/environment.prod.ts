export const environment = {
  production: true,
  baseUrl: 'https://mbpp-elatihan-api.pipe.my/',
  mapbox: {
    accessToken: 'pk.eyJ1IjoiYWZlZXpheml6IiwiYSI6ImNqNjJ6anlhYzA0bTczM3FvYnppbDh4eTEifQ.AdDRr42bNfNJvQENLrE6eg' // Your access token goes here
  }
};
 