import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-lock",
  templateUrl: "lock.component.html"
})
export class LockComponent implements OnInit {
  focus2;
  constructor() {}

  ngOnInit() {}
}
