import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-takwim',
  templateUrl: './takwim.component.html',
  styleUrls: ['./takwim.component.scss']
})
export class TakwimComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
