export const Departments = [
    {
        value: 'KA',
        text: 'Kawalan Bangunan'
    },
    {
        value: 'KN',
        text: 'Kejuruteraan'
    },
    {
        value: 'KK',
        text: 'Kesihatan, Persekitaraan dan Pelesenan'
    },
    {
        value: 'PB',
        text: 'Perbendaharaan'
    },
    {
        value: 'PP',
        text: 'Penilaian dan Pengurusan Harta'
    },
    {
        value: 'UU',
        text: 'Undang-undang'
    },
    {
        value: 'KP',
        text: 'Khidmat Pengurusan'
    },
    {
        value: 'KM',
        text: 'Khidmat Kemasyarakatan'
    },
    {
        value: 'KW',
        text: 'Konservasi Warisan'
    },
    {
        value: 'PB',
        text: 'Pesuruhjaya Bangunan'
    },
    {
        value: 'PG',
        text: 'Penguatkuasaan'
    },
    {
        value: 'PN',
        text: 'Perkhidmatan Perbandaran'
    },
    {
        value: 'LL',
        text: 'Landskap'
    },
    {
        value: 'BP',
        text: 'Bahagian Pelesenan'
    },
    {
        value: 'UD',
        text: 'Unit Audit Dalaman'
    },
    {
        value: 'UO',
        text: 'Unit OSC'
    },
    {
        value: 'NA', 
        text: 'Not Available'
    }
    
]