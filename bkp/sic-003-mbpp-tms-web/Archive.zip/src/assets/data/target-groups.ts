export const TargetGroups = [
    {
        value: 'GD',
        text: 'Gred'
    },
    {
        value: 'JB',
        text: 'Jabatan'
    },
    {
        value: 'JW',
        text: 'Jawatan'
    },
    {
        value: 'SM',
        text: 'Semua'
    },
    {
        value: 'SP',
        text: 'Skim Perkhidmatan'
    }
]