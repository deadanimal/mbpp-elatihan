export const Organisers = [
    {
        value: 'LL',
        text: 'Luaran'
    },
    {
        value: 'DD',
        text: 'Dalaman'
    },
    {
        value: 'OT',
        text: 'Lain-Lain'
    }
]