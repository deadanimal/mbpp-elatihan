export const TargetGroupTypes = [
    {
        value: 'TB',
        text: 'Terbuka'
    },
    {
        value: 'TH',
        text: 'Terhad'
    }
]