export const Courses = [
    {
        value: 'KK',
        text: 'Kursus'
    },
    {
        value: 'PP',
        text: 'Persidangan'
    },
    {
        value: 'SS',
        text: 'Seminar'
    },
    {
        value: 'BB',
        text: 'Bengkel'
    },
    {
        value: 'LK',
        text: 'Lawatan Kerja'
    },
    {
        value: 'TT',
        text: 'Taklimat'
    },
    {
        value: 'SP',
        text: 'Sesi Perjumpaan'
    },
    {
        value: 'OT',
        text: 'Lain-Lain'
    }
]