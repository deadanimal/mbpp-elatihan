export const Results = [
    {
        value: 'PA',
        text: 'Lulus'
    },
    {
        value: 'FA',
        text: 'Gagal'
    }
]