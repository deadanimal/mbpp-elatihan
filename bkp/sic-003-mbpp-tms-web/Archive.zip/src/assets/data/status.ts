export const Status = [
    {
        value: 'DB',
        text: 'Dibuka'
    },
    {
        value: 'DT',
        text: 'Ditutup'
    },
    {
        value: 'PN',
        text: 'Penuh'
    },
    {
        value: 'TN',
        text: 'Tangguh'
    },
    {
        value: 'OT',
        text: 'Lain-lain'
    }
]