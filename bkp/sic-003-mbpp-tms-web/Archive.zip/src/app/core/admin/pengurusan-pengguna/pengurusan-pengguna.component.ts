import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pengurusan-pengguna',
  templateUrl: './pengurusan-pengguna.component.html',
  styleUrls: ['./pengurusan-pengguna.component.scss']
})
export class PengurusanPenggunaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
