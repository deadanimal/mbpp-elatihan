import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pengurusan-log',
  templateUrl: './pengurusan-log.component.html',
  styleUrls: ['./pengurusan-log.component.scss']
})
export class PengurusanLogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
