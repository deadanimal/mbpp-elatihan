import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kursus-lepas',
  templateUrl: './kursus-lepas.component.html',
  styleUrls: ['./kursus-lepas.component.scss']
})
export class KursusLepasComponent implements OnInit {

  // Data
  histories
  
  constructor() { }

  ngOnInit() {
  }

}
