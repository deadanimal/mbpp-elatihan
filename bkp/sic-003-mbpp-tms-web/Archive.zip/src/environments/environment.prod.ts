export const environment = {
  production: true,
  baseUrl: 'https://elatihan.herokuapp.com/'
};
